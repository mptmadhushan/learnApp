const GOOGLE_API_KEY = 'AIzaSyAjO92NdWvu0qpgVhOXZdj89OUGxS94F-U';

export default GOOGLE_API_KEY;
