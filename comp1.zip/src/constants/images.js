const risk = require('../assets/images/risk.png');
const user = require('../assets/images/51f6fb256629fc755b8870c801092942.png');

export default {
  risk,
  user,
};
